"""
Zincir merdiven CDF hesaplama örnek kullanımı.
"""

import pandas as pd
import numpy as np
import os
from triangle_processor import process_data_to_triangle
from utils import export_triangle_to_excel


def main():
    """Ana örnek fonksiyon."""
    print("=" * 50)
    print("Zincir Merdiven CDF Hesaplama Örneği")
    print("=" * 50)
    
    # Excel dosyasından veri yükle
    print("\n1. Excel dosyasından veri yükleniyor...")
    excel_file = 'data.xlsx'
    
    try:
        # Önce Excel dosyasını yükleyip sütunları kontrol et
        if not os.path.exists(excel_file):
            print(f"   ✗ Hata: {excel_file} dosyası bulunamadı!")
            print("   Lütfen data.xlsx dosyasını proje klasörüne ekleyin.")
            return
        
        df = pd.read_excel(excel_file, sheet_name='data')
        print(f"   Veri boyutu: {df.shape}")
        print(f"   Mevcut sütunlar: {df.columns.tolist()}")
        print(f"\n   İlk 10 satır:")
        print(df.head(10).to_string())
        
        # Orijinal sütun adlarını sakla
        original_columns = df.columns.tolist()
        
        # Sütun adlarını normalize et (boşlukları temizle, büyük harfe çevir)
        df_normalized = df.copy()
        df_normalized.columns = df_normalized.columns.str.strip().str.upper()
        
        # Sütun adlarını bul
        accident_col = None
        dev_date_col = None
        paid_col = None
        
        for i, col in enumerate(df_normalized.columns):
            col_upper = col.upper().replace(' ', '_')
            if 'ACCIDENT' in col_upper and ('YEA' in col_upper or 'YEAR' in col_upper):
                accident_col = col  # Normalize edilmiş sütun adı
            elif 'DEVELOPMENT' in col_upper and ('DATE' in col_upper):
                dev_date_col = col  # Normalize edilmiş sütun adı
            elif 'PAID' in col_upper:
                paid_col = col  # Normalize edilmiş sütun adı
        
        if not accident_col:
            print(f"\n   ⚠ Uyarı: Accident year sütunu bulunamadı!")
            print(f"   Mevcut sütunlar: {original_columns}")
            return
        
        if not dev_date_col:
            print(f"\n   ⚠ Uyarı: Development date sütunu bulunamadı!")
            print(f"   Mevcut sütunlar: {original_columns}")
            return
        
        if not paid_col:
            print(f"\n   ⚠ Uyarı: PAID sütunu bulunamadı!")
            print(f"   Mevcut sütunlar: {original_columns}")
            return
        
        print(f"\n   Bulunan sütunlar:")
        print(f"     Accident Year: {accident_col}")
        print(f"     Development Date: {dev_date_col}")
        print(f"     Paid: {paid_col}")
        
        # Normalize edilmiş DataFrame'i kullan
        df = df_normalized
        
        print(f"\n   ✓ {excel_file} dosyası başarıyla yüklendi")
        
        # Veriyi işle: kümülatif, üçgen matris ve dev factor'ler
        print("\n2. Veri işleniyor (kümülatif, üçgen matris, dev factor'ler)...")
        processed_data = process_data_to_triangle(
            df,
            accident_year_column=accident_col,
            development_date_column=dev_date_col,
            value_column=paid_col,
            min_years=5  # Son 5 yıl kullan
        )
        
        print(f"   ✓ Kümülatif veri hazırlandı: {processed_data['cumulative_data'].shape}")
        print(f"   ✓ Üçgen matris oluşturuldu: {processed_data['triangle_df'].shape}")
        print(f"   ✓ Development factor'ler hesaplandı: {len(processed_data['dev_factors'])} period")
        
        # Development factor'leri göster
        print("\n3. Development Factor'ler:")
        for period, factor_data in processed_data['dev_factors'].items():
            if not np.isnan(factor_data['factor']):
                print(f"   Period {period}: {factor_data['factor']:.4f}")
                print(f"     Kullanılan yıllar: {factor_data['used_years']}")
                print(f"     Toplam (Current): {factor_data['sum_current']:,.2f}")
                print(f"     Toplam (Next): {factor_data['sum_next']:,.2f}")
        
        # CDF'leri göster
        print("\n4. CDF Değerleri:")
        for period, cdf_value in processed_data['cdf'].items():
            print(f"   Period {period}: {cdf_value:.4f}")
        
        # Excel'e kaydet (4 sayfa)
        print("\n5. Sonuçlar Excel'e kaydediliyor (4 sayfa: data, kümül data, üçgen, dev factorleri)...")
        try:
            export_triangle_to_excel(processed_data, 'sonuclar.xlsx')
            print("   ✓ sonuclar.xlsx kaydedildi (4 sayfa)")
            
            if os.path.exists('sonuclar.xlsx'):
                file_size = os.path.getsize('sonuclar.xlsx')
                print(f"   ✓ Dosya boyutu: {file_size} bytes")
                
        except Exception as e:
            print(f"   ✗ Sonuçlar kaydedilemedi: {e}")
            import traceback
            traceback.print_exc()
            
    except FileNotFoundError:
        print(f"   ✗ Hata: {excel_file} dosyası bulunamadı!")
        print("   Lütfen data.xlsx dosyasını proje klasörüne ekleyin.")
        return
    except KeyError as e:
        print(f"   ✗ Hata: Sütun bulunamadı: {e}")
        print("   Lütfen Excel dosyasındaki sütun adlarını kontrol edin.")
        return
    except Exception as e:
        print(f"   ✗ Hata: {e}")
        import traceback
        traceback.print_exc()
        return
    
    print("\n" + "=" * 50)
    print("Hesaplama tamamlandı!")
    print("=" * 50)


if __name__ == '__main__':
    main()

